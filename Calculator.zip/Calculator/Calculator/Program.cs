﻿//Somehow the loop still works even though this is false
bool acc = false;
Console.WriteLine("Press \"Y\" to activate\n");
string re = Console.ReadLine();
if (re == "Y" || re == "y")
{
    acc = true;
}
else
{
    //Doesn't work... at all
    Console.WriteLine("Did not activate");
    acc = false;
};

do
{
    //Yes, it can only do math with two numbers
    Console.WriteLine("Write: \n\"add\" - Addition \n\"sub\" - Subtraction \n\"mul\" - Multiplication \n\"div\" - Division \n\"pow\" - To the power of \n\"sqr\" - Square Root \n\"mui\" Inverse Multiplication \n\"per\" - Percent");
    string v = Console.ReadLine();
    Console.WriteLine("Write first number");    
    double x = Convert.ToDouble(Console.ReadLine());
    Console.WriteLine("Write second number");
    double y = Convert.ToDouble(Console.ReadLine());

    if (v == "add")
    {
        double sum = x + y;
        Console.WriteLine(sum);
    }

    else if (v == "sub")
    {
        double sum = x - y;
        Console.WriteLine(sum);
    }

    else if (v == "mul")
    {
        double sum = x * y;
        Console.WriteLine(sum);
    }

    else if (v == "div")
    {
        double sum = x / y;
        Console.WriteLine(sum);
    }

    else if (v == "pow")
    {
        double sum = Math.Pow(x, y);
        Console.WriteLine(sum);
    }

    else if (v == "sqr")
    {
        double sum = Math.Sqrt(x);
        Console.WriteLine(sum);
    }

    else if (v == "mui")
    {
        double sum = 1 / (x);
        Console.WriteLine(sum);
    }

    else if (v == "per")
    {
        double sum = x / (100 / y);
        Console.WriteLine(sum);
    };
}
while (acc == true);